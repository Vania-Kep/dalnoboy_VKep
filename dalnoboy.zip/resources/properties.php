<?php
$ress_wrongLoginOrPass='Неправильний логін або пароль!';
$ress_error_fillAllData='Введіть всі дані!';
$ress_error_loginUsed='Логін вже зайнятий!';
$ress_chooseAnotherLogin='Виберіть інший логін.';
$ress_error_passwordsDontMatch='Паролі не співпадають!';
$ress_error_userDoesntRemoved='Ковристувача не видалено!';
$ress_error_wrongData='Неправильні дані!';
$ress_error_='';
$ress_error_='';
$ress_error_='';
$ress_passWasChangedSuccesfuly='Пароль успішно змінено!';
$ress_='';
$ress_='';
$ress_='';
$ress_='';



?>